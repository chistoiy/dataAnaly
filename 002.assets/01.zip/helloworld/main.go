package main

import "fmt"

const (
	c1 = 123
	c2 = "ops"
)

const (
	n1 = iota
	n2
	n3
)

func main() {

	var (
		s1   string = "helo"
		isOK bool   = true
	)

	//var s1 = "st" string
	fmt.Print(isOK)
	fmt.Printf("string values is : %s", s1)
	fmt.Println("cainiaobulan testing go")

	fmt.Println("const", c1, c2)

	fmt.Println("iota:", n1, n2)
}
